<?php
session_start();
include '../db.php'; // Conexão com o banco de dados

// Verificar se o usuário está logado
if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
    exit;
}

// Obter o termo de pesquisa enviado via GET
$termo = $_GET['termo'] ?? '';

// Buscar produtos que correspondem ao termo (por nome ou código)
$sql = "SELECT id, nome, preco FROM produtos WHERE nome LIKE :termo OR id LIKE :termo LIMIT 10";
$stmt = $pdo->prepare($sql);
$stmt->execute(['termo' => "%$termo%"]);
$produtos = $stmt->fetchAll();

// Gerar os cards de produtos para seleção
$html = '';
foreach ($produtos as $produto) {
    $html .= '
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">' . htmlspecialchars($produto['nome']) . '</h5>
            <p class="card-text">Código: ' . $produto['id'] . '</p>
            <div class="row">
                <div class="col-md-4">
                    <label>Quantidade</label>
                    <input type="number" name="produtos[' . $produto['id'] . '][quantidade]" class="form-control" min="1" required>
                </div>
                <div class="col-md-4">
                    <label>Valor Unitário</label>
                    <input type="number" name="produtos[' . $produto['id'] . '][valor_unitario]" class="form-control" value="' . $produto['preco'] . '" required>
                </div>
            </div>
        </div>
    </div>';
}

echo $html;
